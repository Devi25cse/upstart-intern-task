import json
from dataclasses import dataclass, asdict
from typing import Any


ALLOWED_INTENTS = {
    "order_status",
    "college_info",
    "python_help",
    "unknown",
}


class ValidationError(Exception):
    """Raised when model output does not match the required schema."""


@dataclass(frozen=True)
class ChatbotResult:
    intent: str
    confidence: float
    reply: str


def validate_output(raw: str) -> ChatbotResult:
    """
    Parse and strictly validate model JSON.

    This is the trust boundary: invalid model output is rejected here.
    """
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValidationError(f"Invalid JSON: {exc.msg}") from exc

    if not isinstance(data, dict):
        raise ValidationError("Output must be a JSON object.")

    required = {"intent", "confidence", "reply"}
    actual = set(data.keys())

    missing = required - actual
    extra = actual - required

    if missing:
        raise ValidationError(f"Missing fields: {sorted(missing)}")
    if extra:
        raise ValidationError(f"Unexpected fields: {sorted(extra)}")

    intent = data["intent"]
    confidence = data["confidence"]
    reply = data["reply"]

    if not isinstance(intent, str):
        raise ValidationError("intent must be a string.")
    if intent not in ALLOWED_INTENTS:
        raise ValidationError(
            f"intent must be one of: {sorted(ALLOWED_INTENTS)}"
        )

    # bool is a subclass of int in Python, so reject it explicitly.
    if isinstance(confidence, bool) or not isinstance(confidence, (int, float)):
        raise ValidationError("confidence must be a number.")
    if not 0.0 <= float(confidence) <= 1.0:
        raise ValidationError("confidence must be between 0.0 and 1.0.")

    if not isinstance(reply, str) or not reply.strip():
        raise ValidationError("reply must be a non-empty string.")

    return ChatbotResult(
        intent=intent,
        confidence=float(confidence),
        reply=reply.strip(),
    )


class MockModel:
    """
    Deterministic model simulator.

    First call returns deliberately bad JSON.
    Repair call returns valid JSON.
    Replace this class with a real LLM client in production.
    """

    def __init__(self):
        self.calls = 0

    def generate(self, user_message: str, repair: bool = False) -> str:
        self.calls += 1

        if not repair:
            # Deliberately invalid: confidence is outside 0..1.
            return json.dumps({
                "intent": "order_status",
                "confidence": 1.7,
                "reply": "Please provide your order number."
            })

        return json.dumps({
            "intent": "order_status",
            "confidence": 0.96,
            "reply": "Please provide your order number so I can check the delivery status."
        })


def get_valid_result(model: MockModel, user_message: str, max_attempts: int = 2) -> ChatbotResult:
    """
    Ask the model for JSON, validate it, and repair/retry once if needed.
    """
    raw = model.generate(user_message)

    try:
        return validate_output(raw)
    except ValidationError as first_error:
        print(f"Attempt 1: invalid model output rejected ({first_error})")

        if max_attempts < 2:
            raise

        repaired_raw = model.generate(
            user_message,
            repair=True,
        )

        try:
            result = validate_output(repaired_raw)
        except ValidationError as repair_error:
            raise ValidationError(
                f"Repair failed validation: {repair_error}"
            ) from repair_error

        print("Repair attempt: repaired output accepted.")
        return result


def main() -> None:
    user_message = "My order has not arrived. Can you check the status?"
    model = MockModel()

    result = get_valid_result(model, user_message)

    print("Final typed result:")
    print(json.dumps(asdict(result), indent=2))


if __name__ == "__main__":
    main()
