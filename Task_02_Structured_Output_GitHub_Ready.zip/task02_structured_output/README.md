# Task 02 — Structured Output

## Goal

Make an AI model return JSON that code can safely rely on.

This small project demonstrates three required pieces:

1. **Schema** — defines the exact JSON structure and types expected.
2. **Validation** — rejects missing fields, wrong types, invalid values, and extra fields.
3. **Retry/repair path** — when model output is invalid, the program asks for a repaired JSON response and validates it again.

## Project files

```text
task02_structured_output/
├── structured_output.py
├── requirements.txt
└── README.md
```

## Output schema

The program expects an AI chatbot classification result with this shape:

```json
{
  "intent": "order_status",
  "confidence": 0.95,
  "reply": "Please provide your order number so I can check the status."
}
```

Rules:

- `intent` must be one of:
  - `order_status`
  - `college_info`
  - `python_help`
  - `unknown`
- `confidence` must be a number from `0.0` to `1.0`
- `reply` must be a non-empty string
- No extra fields are allowed

## Validation

The `validate_output()` function parses JSON and checks every schema rule.

Examples of rejected output:

- invalid JSON
- missing `intent`
- `confidence` outside `0–1`
- wrong data type
- empty `reply`
- unknown `intent`
- extra JSON fields

The script raises `ValidationError` instead of allowing bad data to continue.

## Retry / repair path

The script uses a small mock model so the project can run without an API key.

For the first attempt, the mock model intentionally returns invalid JSON. The program:

1. receives the model output,
2. validates it,
3. catches the validation error,
4. sends a repair request,
5. validates the repaired JSON,
6. returns only the validated typed result.

If the repaired output is still invalid, the program raises an error instead of returning unsafe data.

## How to run

### 1. Create a virtual environment (optional)

```bash
python -m venv .venv
```

Activate it:

**Windows**
```bash
.venv\Scripts\activate
```

**macOS/Linux**
```bash
source .venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Run

```bash
python structured_output.py
```

Expected result:

```text
Attempt 1: invalid model output rejected.
Repair attempt: repaired output accepted.
Final typed result:
{
  "intent": "order_status",
  "confidence": 0.96,
  "reply": "Please provide your order number so I can check the delivery status."
}
```

## Design decision

I used a small Python validator instead of depending on a large framework. This keeps the project easy to understand and demonstrates the core idea directly: **never trust model output until it passes validation**.

The mock model is intentional. It makes the retry/repair behavior reproducible for a reviewer without requiring an API key. The same validation boundary can later be connected to a real LLM API.
